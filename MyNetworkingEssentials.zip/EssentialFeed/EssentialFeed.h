//
//  EssentialFeed.h
//  EssentialFeed
//
//  Created by Kumar Utsav on 25/10/24.
//

#import <Foundation/Foundation.h>

//! Project version number for EssentialFeed.
FOUNDATION_EXPORT double EssentialFeedVersionNumber;

//! Project version string for EssentialFeed.
FOUNDATION_EXPORT const unsigned char EssentialFeedVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <EssentialFeed/PublicHeader.h>


